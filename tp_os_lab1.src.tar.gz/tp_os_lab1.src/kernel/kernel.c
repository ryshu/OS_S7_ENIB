#include <target.h>

#include <stdlib.h>

#include "alloc.h"
#include "kernel.h"
#include "list.h"

#ifndef NULL
#define NULL 0
#endif

/*****************************************************************************
 * Global variables
 *****************************************************************************/

static uint32 id=1;
Task * tsk_running=NULL;   /* pointer to ready task list : the first
                                     node is the running task descriptor */
Task * tsk_sleeping=NULL;  /* pointer to sleeping task list */
Context     * saved_ctx=NULL;     /* pointer to current saved context on svc/irq
                                     stack */
/*****************************************************************************
 * Round robin algorithm
 *****************************************************************************/

/* sys_round_robin
 *   change context to next task in the ready list
 */
void sys_round_robin()
{
    // A COMPLETER

//    list_display(tsk_running);
}

/*****************************************************************************
 * General OS handling functions
 *****************************************************************************/

/* sys_os_start
 *   start the first created task
 */
int32 sys_os_start()
{
    // A COMPLETER
    return 0;
}

/*****************************************************************************
 * Task handling functions
 *****************************************************************************/
void task_kill();

/* sys_task_new
 *   create a new task :
 *   tc        : task code to be run
 *   stacksize : task stack size
 */
int32 sys_task_new(TaskCode func, uint32 stacksize)
{
    // A COMPLETER
    return 0;
}

/* sys_task_kill
 *   kill oneself
 */
int32 sys_task_kill()
{
    // A COMPLETER
	return 0;
}

/* sys_task_id
 *   returns id of task
 */
int32 sys_task_id()
{
    // A COMPLETER
	return 0;
}

/* task_wait
 *   suspend the current task until timeout
 */
int32 sys_task_wait(uint32 ms)
{
    return 0;
}


/*****************************************************************************
 * Semaphore handling functions
 *****************************************************************************/

/* sys_sem_new
 *   create a semaphore
 *   init    : initial value
 */
Semaphore * sys_sem_new(int32 init)
{
    // A COMPLETER
    return NULL;
}

/* sys_sem_p
 *   take a semaphore
 */
int32 sys_sem_p(Semaphore * sem)
{
    // A COMPLETER
    return -1;
}

/* sys_sem_v
 *   release a semaphore
 */
int32 sys_sem_v(Semaphore * sem)
{
    // A COMPLETER
    return -1;
}



