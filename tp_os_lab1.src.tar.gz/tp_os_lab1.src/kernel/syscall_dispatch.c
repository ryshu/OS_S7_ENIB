#include "oslib.h"
#include "alloc.h"
#include "kernel.h"

/* sys_add
 *   test function
 */
int sys_add(int a, int b)
{
    // A COMPLETER
}

/* syscall_dispatch
 *   dispatch syscalls
 *   n      : syscall number
 *   args[] : array of the parameters (4 max)
 */
int32 syscall_dispatch(uint32 n, uint32 args[])
{
    switch(n) {
      case 0:
          return sys_add((int)args[0], (int)args[1]);
    }
    return -1;
}

